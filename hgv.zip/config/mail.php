<?php

return array(
  'driver' => 'smtp',
  'host' => 'smtp.sendgrid.net',
  'port' => 587,
  'from' => array('address' => 'from@example.com', 'name' => 'John Smith'),
  'encryption' => 'tls',
  'username' => 'paras18.arora',
  'password' => 'paras123',
);

?>