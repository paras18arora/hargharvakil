<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Mail;
use App\User;

class MailController extends Controller
{
 public function send(Request $request)
    {
      //  $title = $request->input('title');
        //$content = $request->input('content');
        $title='paras';
        $content='content';

        Mail::send('emails.send',['title' => $title, 'content' => $content], function ($message)
        {

            $message->from('paras18.arora@gmail.com', 'paras');

            $message->to('paras18.arora@gmail.com');

        });

        return response()->json(['message' => 'Request completed']);
    }
}
