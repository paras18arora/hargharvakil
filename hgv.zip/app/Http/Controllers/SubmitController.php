<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class SubmitController extends Controller
{
    public function submit(Request $request)
    {
    	$email=$request['email'];
        
    }
}
