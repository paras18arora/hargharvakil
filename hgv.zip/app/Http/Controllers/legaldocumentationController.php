<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use DB;
class legaldocumentationController extends Controller
{
    public function show($id)
    {
    	$data= DB::table('services_list')->where('id', '=' ,  $id)->first();
    	
    	return view('legaldocumentation')->with('data',$data);
    }
}
