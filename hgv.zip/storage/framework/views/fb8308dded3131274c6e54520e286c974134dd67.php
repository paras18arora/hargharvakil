<!DOCTYPE html>
<html>

<!-- Mirrored from htmlbeans.com/lawfirm/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Jul 2016 19:02:36 GMT -->
<head>
    <!-- set the encoding of your site -->
    <meta charset="utf-8">
    <!-- set the viewport width and initial-scale on mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HAR GHAR VAKIL</title>
    <!-- include the site stylesheet -->
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/bootstrap.css">
    <link rel="stylesheet" href="/css/fancybox.css">
    <link rel="stylesheet" href="/css/all.css">
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic%7cRoboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic%7cOpen+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
</head>
<body>

</body>
 <div id="wrapper">
        <!-- header of the page -->
        <header id="header">
            
            <div class="container-fluid pad-left-right">
                <div class="row">
                    <div >
                        <!-- logo of the page -->
                        <div class="logo "><a href="#"><img src="/images/logo.png" alt="LAW FIRM THEME FOR Law"></a></div>
                        <a href="#" class="nav-opener visible-xs"><i class="fa fa-bars"></i></a>
                        <div class="nav-holder ">
                            
                            <!-- nav of the page -->
                            <nav id="nav">
                                <ul class="list-inline">
                                    <li class="active">
                                        <a href="/">Home</a>
                                    </li>
                                    <li><a href="/aboutus">About Us</a></li>
                                    <li class="m-drop">Legal Services
                                    <div class="mega-drop">
                                            <div class="drop-holder">
                                                <div class=""> 
                                                    <ul class="list-unstyled">
                                                        <li><strong>INDUSTRIAL PROPERTY</strong></li>
                                                        <li><a href="/industrialproperty/1">TRADEMARK REGISTRATION</a></li>
                                                        <li><a href="/industrialproperty/2">TRADEMARK RENEWAL</a></li>
                                                        <li><a href="/industrialproperty/3">TRADEMARK OBJECTION</a></li>
                                                        <li><a href="/industrialproperty/4">TRADEMARK ASSIGNMENT</a></li>
                                                        <li><a href="/industrialproperty/5">COPYRIGHT REGISTRATION</a></li>
                                                        <li><a href="/industrialproperty/6">PATENT SEARCH</a></li>
                                                        <li><a href="/industrialproperty/7">PROVISIONAL PATENT</a></li>
                                                    </ul>
                                                    <ul class="list-unstyled">
                                                        <li><strong>LEGAL DOCUMENTS</strong></li>
                                                        <li><a href="/legaldocumentation/8">LEGAL NOTICE</a></li>
                                                        <li><a href="/legaldocumentation/9">AGREEMENTS</a></li>
                                                        <li><a href="/legaldocumentation/10">CONTRACTS</a></li>
                                                        <li><a href="/legaldocumentation/11">NON DISCLOSURE AGREEMENTS</a></li>
                                                        <li><a href="/legaldocumentation/12">DEEDS</a></li>
                                                        <li><a href="/legaldocumentation/13">WILLS</a></li>
                                                        <li><a href="/legaldocumentation/14">POLICIES AND DISCLAIMERS</a></li>
                                                        <li><a href="/legaldocumentation/15">APP-RELATED AGREEMENTS</a></li>
                                                    </ul>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </li>
                                    <li  class="m-drop">CA/CS & Registrations
                                    <div class="mega-drop">
                                            <div class="drop-holder">
                                                <div class="">
                                                    <ul class="list-unstyled">
                                                        <li><strong>INCORPORATIONS</strong></li>
                                                        <li><a href="event-details.html">COMPANIES</a></li>
                                                        <li><a href="news.html">SOLO ENTREPRENEURS</a></li>
                                                        <li><a href="news-details.html">PATNERSHIPS</a></li>
                                                        <li><a href="testimonial.html">AGREEMENTS</a></li>
                                                        <li><a href="testimonial.html">AMENDMENTS IN AGREEMENTS</a></li>
                                                        <li><a href="testimonial.html">ANNUAL COMPLIANCES</a></li>
                                                        <li><a href="testimonial.html">CONVERSIONS</a></li>
                                                        <li><a href="testimonial.html">ACCOUNTS MAINTENANCE</a></li>
                                                        <li><a href="testimonial.html">WINDING UP</a></li>

                                                    </ul>
                                                    <ul class="list-unstyled">
                                                        <li><strong>TAX REGISTRATION AND FILING</strong></li>
                                                        <li><a href="team.html">VAT</a></li>
                                                        <li><a href="team-details.html">SERVICE TAX</a></li>
                                                        <li><a href="shortcodes.html">PROFESSIONAL TAX</a></li>
                                                        <li><a href="icons.html">TDC</a></li>
                                                        <li><a href="icons.html">TDS</a></li>
                                                    </ul>
                                                    <ul class="list-unstyled">
                                                        <li><strong>MISCELLANEOUS</strong></li>
                                                        <li><a href="team.html">PASSPORT REGISTRATION</a></li>
                                                        <li><a href="team-details.html">PASSPORT RENEWAL</a></li>
                                                        <li><a href="shortcodes.html">DIN REGISTRATION</a></li>
                                                        <li><a href="icons.html">TIN REGISTRATION</a></li>
                                                        
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                    <li><a href="testimonial.html">Legal Advice</a></li>
                                    <li>
                                        <a href="blog.html">Legal Consultancy</a>
                                        <div class="small-drop add">
                                            <div class="drop-holder">
                                                <ul class="list-unstyled">
                                                    <li><a href="blog-details.html">CLAT</a></li>
                                                    <li><a href="blog-detail-sliderpost.html">LLM</a></li>
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                    
                                    <!--<li><a href="contactus.html">Contact</a></li>-->
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-gallery of the Page -->
<?php echo $__env->yieldContent('information'); ?>
</html>