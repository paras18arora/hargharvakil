
@extends('layout')

@section('information')
		<!-- banner-block of the Page -->
		<div class="banner-block">
		<meta name="csrf-token1" content="{!! Session::token() !!}">
   
			<div class="container">
				<div class="row">
					<div class="col-xs-12 banner-box">
						<header class="banner-heading">
							<h1>Industrial Property</h1>
							<!-- breadcrumbs of the page -->
							
						</header>
					</div>
				</div>
			</div>
			<div class="bg-stretch">
				<img src="/images/img41.jpg" alt="image description">
			</div>
		</div>
		<!-- contain main informative part of the site -->
		<main id="main">
			<!-- container-block about of the page -->
			<div class="container container-block about">
				<!-- about-block of the page -->
				<div class="row about-block">
					
					<div class="col-sm-12 col-xs-12 txt-box">
				
					        <p class="aboutuscontent">
						   Trademarks, copyrights and patents are the grey areas of law which needs great expertise and help. The intellectual property is the intangible property of a company which is a major asset to the company but requires great caution in protecting the same. Trademarks, copyrights and patents are kinds of intellectual property. 
						    </p>
						    <br>
						    <h3>Trademark</h3>
					        <p class="aboutuscontent">
                            A trademark is a recognizable sign, design or expression which identifies products or services of a particular source from those of others. The trademark owner can be an individual, business organization, or any legal entity.
                            <br>
                            When a trademark application is filed, the Trade Marks Office may object it for various reasons. Reasons can be deceptive similarity, confusion in the minds of the consumers or anything which seems objectionable to the Office. Once your trademark is objected, a response has to be filed within a month of the publication of the objection else it can lead to the abandonment of the application. An objection is merely a clarification required and thus should be responded to instantly for easy use of the trademark. 
                            <br>
                            The validity of registered trademarks is ten years and can always be renewed indefinitely. Once the trademark reaches the expiry date, the owner gets a time period of 6 months to apply for renewal. 
                            <br>
                            </p>
						    
						    <h3>Copyright Registration</h3>
					        <p class="aboutuscontent">
                            Copyright Registration gives the owner the sole right to copy or reproduce the work or grant permission to another to do so. It applies to literary (books, scripts, even software) and audio-visual (music, photographs, movies) works. Copyrights, valid for 60 years, are also transferrable.
                            <br>
                            Based on novelty, industrial application and the inventive nature, a patent is granted to the inventor who gets the exclusive right over the invention. A thorough check is always done so as to find out whether the invention already exists or is similar to any other patent. This search is very important and is a necessity before filing for a patent. 

                            </p>
						    <br>
						   
						
						
					</div>
				</div>
			
			</div>
			<!-- clients-gallery of the Page -->
			<center>
			<h2>
			{{$data->service_name}}
			</h2>
			</center>
			 <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <form id="contact-us" method="post" action="/send">
                     <input type="hidden" name="_token" value="{{ Session::token() }}">  
                        <!-- Left Inputs -->
                        <div class="col-xs-6 wow animated slideInLeft" data-wow-delay=".5s">
                            <!-- Name -->
                            <input type="text" name="name" id="name" required="required" class="form" placeholder="Name" />
                            <!-- Email -->
                            <input type="email" name="mail" id="mail" required="required" class="form" placeholder="Email" />
                            <!-- Subject -->
                            <input type="number" name="subject" id="subject" required="required" class="form" placeholder="Contact no" />
                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <div class="col-xs-6 wow animated slideInRight" data-wow-delay=".5s">
                            <!-- Message -->
                            <textarea name="message" id="message" class="form textarea"  placeholder="comments"></textarea>
                        </div><!-- End Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="relative fullwidth col-xs-12">
                            <!-- Send Button -->
                            <p>Please fill in the details and we shall get back to you in less than 48 hours.</p>
                            <button type="submit" id="submit" name="submit" class="form-btn semibold">Submit</button> 

                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                    </form>

                    <!-- Your Mail Message -->
                    <div class="mail-message-area">
                        <!-- Message -->
                        <div class="alert gray-bg mail-message not-visible-message">
                            <strong>Thank You !</strong> Your email has been delivered.
                        </div>
                    </div>
                    </div>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
			
			</div>
			
			
			
        <br>
        <br>
		<!-- footer of the Page -->
		<footer id="footer">
			<div class="container holder">
				<div class="row">
					<div class="col-sm-5 col-xs-12 copyrights">
						<p>&copy; Copyrights Reserved To <a href="www.htmlbeans.html">HTML BEANS</a>.</p>
					</div>
					<div class="col-sm-7 col-xs-12 copyrights">
						<ul class="footer-nav list-inline">
							<li><a href="index.html">Home</a></li>
							<li><a href="aboutus.html">About Us</a></li>
							<li><a href="practice-area.html">Practise</a></li>
							<li><a href="services.html">Services</a></li>
							<li><a href="testimonial.html">Testimonial</a></li>
							<li><a href="blog.html">Blog</a></li>
							<li><a href="team.html">team</a></li>
							<li><a href="team.html">Contact Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<div class="pre-loader"><span class="preloader1"></span></div>
	</div>
	<!-- include jQuery -->
	<script type="text/javascript" src="/js/jquery-1.11.2.min.js"></script>
	<script type="text/javascript" src="/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/js/jquery.main.js"></script>
	<script type="text/javascript" src="/js/jquery.datepicker.js"></script>
	<script type="text/javascript">
	    if (navigator.userAgent.match(/IEMobile\/10\.0/) || navigator.userAgent.match(/MSIE 10.*Touch/)) {
	        var msViewportStyle = document.createElement('style')
	        msViewportStyle.appendChild(
	            document.createTextNode(
	                '@-ms-viewport{width:auto !important}'
	            )
	        )
	        document.querySelector('head').appendChild(msViewportStyle)
	    }
	</script>
@stop