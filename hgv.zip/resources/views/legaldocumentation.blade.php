
@extends('layout')

@section('information')
		<!-- banner-block of the Page -->
		<div class="banner-block">
		
   
			<div class="container">
				<div class="row">
					<div class="col-xs-12 banner-box">
						<header class="banner-heading">
							<h1>Legal Documentation</h1>
							<!-- breadcrumbs of the page -->
							
						</header>
					</div>
				</div>
			</div>
			<div class="bg-stretch">
				<img src="/images/img41.jpg" alt="image description">
			</div>
		</div>
		<!-- contain main informative part of the site -->
		<main id="main">
			<!-- container-block about of the page -->
			<div class="container container-block about">
				<!-- about-block of the page -->
				<div class="row about-block">
					
					<div class="col-sm-12 col-xs-12 txt-box">
					<h3>Legal Notice</h3>
					<p class="aboutuscontent">
						    A legal notice is the medium which informs the receiver about the legal proceedings initiated against him/her. It is a formal warning which needs immediate action on receiving.
						    </p>
						    <br>
						    <h3>Agreements And Contracts</h3>
					        <p class="aboutuscontent">
                            Agreements and contracts are legal documents which are mutually agreed upon by two or more parties. Drafting agreements and contracts require precision and they must be very specific since they form the base to any venture or project. We are willing to draft the documents for you in the best possible manners and are ready to help with follow-ups and assistance as to the requirements. 
                            </p>
						    <br>
						    <h3>Non-Disclosure Agreements</h3>
					        <p class="aboutuscontent">
                            Non-Disclosure Agreements are another type of agreement which is essential for maintaining the confidentiality of information, data or even an idea expressed to another party. With emerging start-ups and innovations, it is very important to have a well drafted NDA in place for a successful start to projects. 
                            </p>
						    <br>
						    <h3>Deeds and Wills</h3>
					        <p class="aboutuscontent">
                            Deeds and wills are documents that we come across in our daily lives. Be it transfer of property as gifts, will or even rental agreements, the terms of contract have to be crisp and clear. Signatures, attestations and registrations have to be dealt with caution. Charges for the same would be different for different states, purposes and property values. 
                            </p>
						    <br>
						    <h3>Policies and Disclaimers</h3>
					        <p class="aboutuscontent">
                            Policies and disclaimers are app-related agreements where information is displayed and consent is taken from the user as to the terms of service and the use of information. We shall use the best of policies and conditions to keep the application owners protected from legal hassles on the use of their services by users. 
                            </p>
						    <br>
						
						 
						
						
					</div>
				
			<center>
			<h2>
			{{$data->service_name}}
			</h2>
			</center>
            <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <form id="contact-us" method="post" action="/send">
                     <input type="hidden" name="_token" value="{{ Session::token() }}">  
                        <!-- Left Inputs -->
                        <div class="col-xs-6 wow animated slideInLeft" data-wow-delay=".5s">
                            <!-- Name -->
                            <input type="text" name="name" id="name" required="required" class="form" placeholder="Name" />
                            <!-- Email -->
                            <input type="email" name="mail" id="mail" required="required" class="form" placeholder="Email" />
                            <!-- Subject -->
                            <input type="number" name="subject" id="subject" required="required" class="form" placeholder="Contact no" />
                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <div class="col-xs-6 wow animated slideInRight" data-wow-delay=".5s">
                            <!-- Message -->
                            <textarea name="message" id="message" class="form textarea"  placeholder="comments"></textarea>
                        </div><!-- End Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="relative fullwidth col-xs-12">
                            <!-- Send Button -->
                            <p>Please fill in the details and we shall get back to you in less than 48 hours.</p>
                            <button type="submit" id="submit" name="submit" class="form-btn semibold">Submit</button> 

                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                    </form>

                    <!-- Your Mail Message -->
                    <div class="mail-message-area">
                        <!-- Message -->
                        <div class="alert gray-bg mail-message not-visible-message">
                            <strong>Thank You !</strong> Your email has been delivered.
                        </div>
                    </div>
                    </div>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
			
			</div>
			
			
			
        <br>
        <br>


			<!-- clients-gallery of the Page -->
			
		<!-- footer of the Page -->
		<footer id="footer">
			<div class="container holder">
				<div class="row">
					<div class="col-sm-5 col-xs-12 copyrights">
						<p>&copy; Copyrights Reserved To HAR GHAR VAKIL.</p>
					</div>
					<div class="col-sm-7 col-xs-12 copyrights">
						<ul class="footer-nav list-inline">
							<li><a href="index.html">Home</a></li>
							<li><a href="aboutus.html">About Us</a></li>
							<li><a href="practice-area.html">Practise</a></li>
							<li><a href="services.html">Services</a></li>
							<li><a href="testimonial.html">Testimonial</a></li>
							<li><a href="blog.html">Blog</a></li>
							<li><a href="team.html">team</a></li>
							<li><a href="team.html">Contact Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<div class="pre-loader"><span class="preloader1"></span></div>
	</div>
	<!-- include jQuery -->
	<script type="text/javascript" src="/js/jquery-1.11.2.min.js"></script>
	<script type="text/javascript" src="/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="/js/jquery.main.js"></script>
	<script type="text/javascript" src="/js/jquery.datepicker.js"></script>
	<script type="text/javascript">
	    if (navigator.userAgent.match(/IEMobile\/10\.0/) || navigator.userAgent.match(/MSIE 10.*Touch/)) {
	        var msViewportStyle = document.createElement('style')
	        msViewportStyle.appendChild(
	            document.createTextNode(
	                '@-ms-viewport{width:auto !important}'
	            )
	        )
	        document.querySelector('head').appendChild(msViewportStyle)
	    }
	</script>
@stop