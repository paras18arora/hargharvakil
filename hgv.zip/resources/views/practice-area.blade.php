
@extends('layout')

@section('information')
		<!-- banner-block of the page -->
		<div class="banner-block">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 banner-box">
						<header class="banner-heading">
							<h1>PRACTICE AREAS</h1>
							<!-- breadcrumbs of the page -->
							<nav class="breadcrumbs">
								<ul class="list-inline">
									<li><a href="#">Home</a></li>
									<li><a href="#"> Practice Area</a></li>
								</ul>
							</nav>
						</header>
					</div>
				</div>
			</div>
			<div class="bg-stretch">
				<img src="images/img41.jpg" alt="image description">
			</div>
		</div>
		<!-- contain main informative part of the site -->
		<main id="main">
			<!-- container-block of the page -->
			<section class="container container-block practice practice2">
				<div class="row practice-block">
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img04-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img04-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img04-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img04-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Trade mark Cases</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Trade mark Cases</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img05-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img05-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img05-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img05-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Crime Cases</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Crime Cases</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img06-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img06-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img06-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img06-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Accidental Cases</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Accidental Cases</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>
				<div class="row practice-block">
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img55-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img55-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img55-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img55-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Real Estate &amp; Land</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Real Estate &amp; Land</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img56-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img56-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img56-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img56-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Business &amp; Financial</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Business &amp; Financial</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img57-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img57-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img57-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img57-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Family Law</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Family Law</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>
				<div class="row practice-block">
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img58-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img58-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img58-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img58-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Fraud cases</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Fraud cases</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img59-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img59-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img59-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img59-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Drug Offences</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Drug Offences</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
					<div class="col-sm-4 col-xs-12 practice-col">
						<a href="#">
							<span data-picture data-alt="image description">
								<span data-src="images/img60-large.jpg" data-width="368" data-height="279"></span>
								<span data-src="images/img60-large2x.jpg" data-width="736" data-height="558" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
								<!--[if (lt IE 9) & (!IEMobile)]>
									<span data-src="images/img60-large.jpg"></span>
								<![endif]-->
								<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
								<noscript><img src="images/img60-large.jpg" width="368" height="279" alt="image description" ></noscript>
							</span>
							<h3>Money Laundering</h3>
							<div class="over">
								<div class="box">
									<div class="block">
										<div class="frame">
											<strong class="title">Money Laundering</strong>
											<p>Curabitur mollis neque vel ligula congue convallis id tristique</p>
											<span class="btn-read">[+]</span>
										</div>
									</div>
								</div>
							</div>
						</a>
					</div>
				</div>
			</section>
			<section class="container container-block clients2">
				<div class="row">
					<div class="col-xs-12">
						<header class="main-heading">
							<h2>Our Clients</h2>
						</header>
					</div>
				</div>
				<!-- our-clients of the page -->
				<div class="row our-clients">
					<div class="col-xs-12">
						<!-- clients-carousel of the page -->
						<div class="clients-carousel">
							<div class="clients-mask">
								<div class="clients-slideset">
									<div class="clients-slide">
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="85" data-width="134" data-src="images/img28-large.png"></span>
												<span data-src="images/img28-large2x.png" data-width="268" data-height="170" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img28-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img28-large.png" width="134" height="85" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="77" data-width="200" data-src="images/img30-large.png"></span>
												<span data-src="images/img30-large2x.png" data-width="200" data-height="154" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img30-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img30-large.png" width="200" height="154" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="88" data-width="88" data-src="images/img32-large.png"></span>
												<span data-src="images/img32-large2x.png" data-width="176" data-height="176" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img32-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img32-large.png" width="88" height="88" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="52" data-width="142" data-src="images/img34-large.png"></span>
												<span data-src="images/img34-large2x.png" data-width="284" data-height="104" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img34-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img34-large.png" width="142" height="52" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="86" data-width="79" data-src="images/img36-large.png"></span>
												<span data-src="images/img36-large2x.png" data-width="158" data-height="172" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img36-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img36-large.png" width="79" height="86" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="85" data-width="134" data-src="images/img28-large.png"></span>
												<span data-src="images/img28-large2x.png" data-width="268" data-height="170" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img28-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img28-large.png" width="134" height="85" alt="image description" ></noscript>
											</span>
											
										</a>
									</div>
									<div class="clients-slide">
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="85" data-width="134" data-src="images/img28-large.png"></span>
												<span data-src="images/img28-large2x.png" data-width="268" data-height="170" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img28-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img28-large.png" width="134" height="85" alt="image description" ></noscript>
											</span>
											
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="77" data-width="200" data-src="images/img30-large.png"></span>
												<span data-src="images/img30-large2x.png" data-width="200" data-height="154" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img30-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img30-large.png" width="200" height="154" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="88" data-width="88" data-src="images/img32-large.png"></span>
												<span data-src="images/img32-large2x.png" data-width="176" data-height="176" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img32-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img32-large.png" width="88" height="88" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="52" data-width="142" data-src="images/img34-large.png"></span>
												<span data-src="images/img34-large2x.png" data-width="284" data-height="104" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img34-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img34-large.png" width="142" height="52" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="86" data-width="79" data-src="images/img36-large.png"></span>
												<span data-src="images/img36-large2x.png" data-width="158" data-height="172" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img36-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img36-large.png" width="79" height="86" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="85" data-width="134" data-src="images/img28-large.png"></span>
												<span data-src="images/img28-large2x.png" data-width="268" data-height="170" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img28-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img28-large.png" width="134" height="85" alt="image description" ></noscript>
											</span>
											
										</a>
									</div>
									<div class="clients-slide">
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="85" data-width="134" data-src="images/img28-large.png"></span>
												<span data-src="images/img28-large2x.png" data-width="268" data-height="170" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img28-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img28-large.png" width="134" height="85" alt="image description" ></noscript>
											</span>
											
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="77" data-width="200" data-src="images/img30-large.png"></span>
												<span data-src="images/img30-large2x.png" data-width="200" data-height="154" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img30-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img30-large.png" width="200" height="154" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="88" data-width="88" data-src="images/img32-large.png"></span>
												<span data-src="images/img32-large2x.png" data-width="176" data-height="176" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img32-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img32-large.png" width="88" height="88" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="52" data-width="142" data-src="images/img34-large.png"></span>
												<span data-src="images/img34-large2x.png" data-width="284" data-height="104" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img34-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img34-large.png" width="142" height="52" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="86" data-width="79" data-src="images/img36-large.png"></span>
												<span data-src="images/img36-large2x.png" data-width="158" data-height="172" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img36-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img36-large.png" width="79" height="86" alt="image description" ></noscript>
											</span>
										</a>
										<a class="img-holder" href="#">
											<span data-picture data-alt="image description">
												<span data-height="85" data-width="134" data-src="images/img28-large.png"></span>
												<span data-src="images/img28-large2x.png" data-width="268" data-height="170" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
												<!--[if (lt IE 9) & (!IEMobile)]>
													<span data-src="images/img28-large.png"></span>
												<![endif]-->
												<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
												<noscript><img src="images/img28-large.png" width="134" height="85" alt="image description" ></noscript>
											</span>
										</a>
									</div>
								</div>
							</div>
							<a href="#" class="btn-prev2"><i class="fa fa-angle-left"></i></a>
							<a href="#" class="btn-next2"><i class="fa fa-angle-right"></i></a>
						</div>
					</div>
				</div>
			</section>
		</main>
		<!-- footer-holder of the Page -->
		<div class="container footer-holder">
			<aside class="row aside-block">
				<section class="col-sm-6 col-md-3 col-xs-12 column">
					<h2>Newsletters</h2>
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat .</p>
					<a href="#" class="read-more">Read More »</a>
					<h3>Email Newsletters:</h3>
					<form action="#" class="email-form">
						<div class="form-group">
							<input type="email" class="form-control" placeholder="Enter Address">
							<button type="submit" class="btn btn-default"><i class="fa fa-envelope"></i></button>
						</div>
					</form>
					<a class="privacy" href="#">Privacy Policy</a>
				</section>
				<section class="col-sm-6 col-md-3 col-xs-12 column new-col">
					<h2>Latest News</h2>
					<div class="news-articles">
						<div class="news-column">
							<div class="alignleft">
								<a href="images/img07-large2x.jpg" class="lightbox">
									<span data-picture data-alt="image description">
										<span data-src="images/img38-large.jpg" data-width="70" data-height="70"></span>
										<span data-src="images/img38-large2x.jpg" data-width="140" data-height="140" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
										<!--[if (lt IE 9) & (!IEMobile)]>
											<span data-src="images/img38-large.jpg"></span>
										<![endif]-->
										<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
										<noscript><img src="images/img38-large.jpg" width="70" height="70" alt="image description" ></noscript>
									</span>
									<span class="btn-zoom"><i class="fa fa-search"></i></span>
								</a>
							</div>
							<div class="txt-box">
								<p><a href="#">Corem ipsum dolor sit amet, consectetuer adipiscing...</a></p>
								<time datetime="2015-01-01"><a href="#">04 February 2015</a></time>
							</div>
						</div>
						<div class="news-column">
							<div class="alignleft">
								<a href="images/img66-large.jpg" class="lightbox">
									<span data-picture data-alt="image description">
										<span data-src="images/img39-large.jpg" data-width="70" data-height="70"></span>
										<span data-src="images/img39-large2x.jpg" data-width="140" data-height="140" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
										<!--[if (lt IE 9) & (!IEMobile)]>
											<span data-src="images/img39-large.jpg"></span>
										<![endif]-->
										<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
										<noscript><img src="images/img39-large.jpg" width="70" height="70" alt="image description" ></noscript>
									</span>
									<span class="btn-zoom"><i class="fa fa-search"></i></span>
								</a>
							</div>
							<div class="txt-box">
								<p><a href="#">Corem ipsum dolor sit amet, consectetuer adipiscing...</a></p>
								<time datetime="2015-01-01"><a href="#">28 January 2015</a></time>
							</div>
						</div>
						<div class="news-column">
							<div class="alignleft">
								<a href="images/img65-large2x.jpg" class="lightbox">
									<span data-picture data-alt="image description">
										<span data-src="images/img40-large.jpg" data-width="70" data-height="70"></span>
										<span data-src="images/img40-large2x.jpg" data-width="140" data-height="140" data-media="(-webkit-min-device-pixel-ratio:1.5), (min-resolution:1.5dppx)" ></span> <!-- retina 2x desktop -->
										<!--[if (lt IE 9) & (!IEMobile)]>
											<span data-src="images/img40-large.jpg"></span>
										<![endif]-->
										<!-- Fallback content for non-JS browsers. Same img src as the initial, unqualified source element. -->
										<noscript><img src="images/img40-large.jpg" width="70" height="70" alt="image description" ></noscript>
									</span>
									<span class="btn-zoom"><i class="fa fa-search"></i></span>
								</a>
							</div>
							<div class="txt-box">
								<p><a href="#">Corem ipsum dolor sit amet, consectetuer adipiscing...</a></p>
								<time datetime="2015-01-01"><a href="#">03 January 2015</a></time>
							</div>
						</div>
					</div>
				</section>
				<section class="col-sm-6 col-md-3 col-xs-12 column new-col clearfix-sm">
					<h2>Twitter Widget</h2>
					<div class="news-articles twitter">
						<div class="news-column">
							<i class="fa fa-twitter-square"></i>
							<div class="txt-box">
								<p>Raritas ess dynamicus, qui sequitur mutationem <a href="#">http://t.co/hVtABj5tZo</a></p>
								<time datetime="2015-01-01"><a href="#">23 seconds ago</a></time>
							</div>
						</div>
						<div class="news-column">
							<i class="fa fa-twitter-square"></i>
							<div class="txt-box">
								<p>Duis autem vel eum #iriure dolor in hendrerit in vulputate velit</p>
								<time datetime="2015-01-01"><a href="#">8 months ago</a></time>
							</div>
						</div>
						<div class="news-column">
							<i class="fa fa-twitter-square"></i>
							<div class="txt-box">
								<p>@frankdoe am liber tempor cum soluta nobis eleifend</p>
								<time datetime="2015-01-01"><a href="#">2 years ago</a></time>
							</div>
						</div>
					</div>
				</section>
				<section class="col-sm-6 col-md-3 col-xs-12 column new-col">
					<h2>Get In Touch</h2>
					<div class="news-articles address">
						<div class="news-column">
							<span class="txt">Address:</span>
							<address class="address-box">795 South Park Avenue, Door 6 Wonderland, CA 94107, Australia</address>
						</div>
						<div class="news-column">
							<span class="txt">Phone:</span>
							<address class="address-box"><a class="tel" href="tel:440875369208">+440 875369208</a> - Office <br><a class="tel" href="tel:440353363114">+440 353363114</a> - Fax <br><a href="mailo:&#115;&#117;&#112;&#112;&#111;&#114;&#116;&#064;&#115;&#105;&#116;&#101;&#110;&#097;&#109;&#101;&#046;&#099;&#111;&#109;">&#115;&#117;&#112;&#112;&#111;&#114;&#116;&#064;&#115;&#105;&#116;&#101;&#110;&#097;&#109;&#101;&#046;&#099;&#111;&#109;</a></address>
						</div>
						<div class="news-column">
							<span class="txt">Follow:</span>
							<ul class="footer-socials list-inline">
								<li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter-square"></i></a></li>
								<li><a href="#"><i class="fa fa-tumblr-square"></i></a></li>
								<li><a href="#"><i class="fa fa-linkedin-square"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus-square"></i></a></li>
								<li><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest-square"></i></a></li>
								<li><a href="#"><i class="fa fa-flickr"></i></a></li>
								<li><a href="#"><i class="fa fa-youtube-square"></i></a></li>
								<li><a href="#"><i class="fa fa-rss-square"></i></a></li>
								<li><a href="#"><i class="fa fa-git-square"></i></a></li>
								<li><a href="#"><i class="fa fa-hacker-news"></i></a></li>
							</ul>
						</div>
					</div>
				</section>
			</aside>
		</div>
		<!-- footer of the Page -->
		<footer id="footer">
			<div class="container holder">
				<div class="row">
					<div class="col-sm-5 col-xs-12 copyrights">
						<p>&copy; Copyrights Reserved To <a href="www.htmlbeans.html">HTML BEANS</a>.</p>
					</div>
					<div class="col-sm-7 col-xs-12 copyrights">
						<ul class="footer-nav list-inline">
							<li><a href="index.html">Home</a></li>
							<li><a href="aboutus.html">About Us</a></li>
							<li><a href="practice-area.html">Practise</a></li>
							<li><a href="services.html">Services</a></li>
							<li><a href="testimonial.html">Testimonial</a></li>
							<li><a href="blog.html">Blog</a></li>
							<li><a href="team.html">team</a></li>
							<li><a href="team.html">Contact Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>
		<div class="pre-loader"><span class="preloader1"></span></div>
	</div>
	<!-- include jQuery -->
	<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/jquery.main.js"></script>
	<script type="text/javascript" src="js/jquery.datepicker.js"></script>
	<script type="text/javascript">
	    if (navigator.userAgent.match(/IEMobile\/10\.0/) || navigator.userAgent.match(/MSIE 10.*Touch/)) {
	        var msViewportStyle = document.createElement('style')
	        msViewportStyle.appendChild(
	            document.createTextNode(
	                '@-ms-viewport{width:auto !important}'
	            )
	        )
	        document.querySelector('head').appendChild(msViewportStyle)
	    }
	</script>
@stop